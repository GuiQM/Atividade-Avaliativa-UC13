import { FilmeController } from "../controllers/FilmeController";
import { Router } from "express";

const controller = new FilmeController();
const router = Router();

router.post("/filmes", controller.criarFilme);
router.put("/filmes/:id", controller.editFilme);
router.get("filmes/:id", controller.getFilme)
router.delete("/filmes/:id", controller.deletarFilme);
router.get("filmes/getAll", controller.getAllFilmes)

export default router;
