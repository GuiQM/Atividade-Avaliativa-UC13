import { Filme } from "../models/Filmes";
import { Request, Response } from "express";
import { AppDataSource } from "../database/data-source";

const filmeRepository = AppDataSource.getRepository(Filme);

export class FilmeController {
  //CRIAR FILME
  async criarFilme(req: Request, res: Response) {
    const { titulo, descricao, diretor, ano } = req.body;
    if (!titulo || !descricao || !diretor || !ano) {
      res.status(400).json({ message: "Todos os campos são necessários" });
      return;
    }
    const existFilm = await filmeRepository.findOneBy({ titulo });
    if (existFilm) {
      res
        .status(409)
        .json({ message: "Este filme já está inserido no banco de dados!" });
      return;
    }

    const filme = new Filme(titulo, descricao, diretor, ano);
    const newFilme = filmeRepository.create(filme);

    await filmeRepository.save(newFilme);
    res
      .status(201)
      .json({ message: "Filme adicionado com sucesso!", filme: newFilme });
    return;
  }

  //DELETAR FILME
  async deletarFilme(req: Request, res: Response) {
    const id = parseInt(req.params.id);

    if (!id || isNaN(id)) {
      res.status(400).json({ message: "Insira um ID válido" });
      return;
    }

    const filme = await filmeRepository.findOneBy({ id });

    if (!filme) {
      res.status(404).json({ message: "Filme não encontrado." });
      return;
    }

    await filmeRepository.remove(filme);
    res.status(200).json({ message: "Filme excluído com sucesso!" });
    return;
  }

  //GET FILME

  async getFilme(req: Request, res: Response) {
    const id = parseInt(req.params.id);
    if (!id || isNaN(id)) {
      res.status(400).json({ message: "Insira um ID válido" });
      return;
    }
    const filme = await filmeRepository.findOneBy({ id });
    if (!filme) {
      res.status(404).json({ message: "Filme não encontrado" });
    } else {
      res.status(200).json(filme);
      return;
    }
  }

  //GET ALL FILMES
  async getAllFilmes(req: Request, res: Response) {
    const filmes = await filmeRepository.find();
    res.status(200).json({ filmes });
  }


  async editFilme(req: Request, res: Response) {
    const { titulo, descricao, diretor, ano } = req.body;
    const id = parseInt(req.params.id);
    if (!id || isNaN(id)) {
      res.status(400).json({ message: "Insira um ID válido" });
      return;
    }

    const filme = await filmeRepository.findOneBy({ id });

    if (!filme) {
      res.status(404).json({ message: "Filme não encontrado" });
      return;
    }
    if (titulo) filme.titulo = titulo;
    if (descricao) filme.descricao = descricao;
    if (diretor) filme.diretor = diretor;
    if (ano) filme.ano = ano;
    await filmeRepository.save(filme);
    res.status(200).json({ message: "Filme atualizado com sucesso!", filme });
    return;
  }
}