import { Entity, Column, PrimaryGeneratedColumn } from "typeorm";

@Entity ('filmes')

export class Filme{
    @PrimaryGeneratedColumn()
    id!: number

    @Column({type: "varchar", length: 100, nullable: false, unique: true})
    titulo: string;

    @Column({type: "varchar", length: 500, nullable: false, unique: true})
    descricao: string;

    @Column({type: "varchar", length: 100, nullable: false})
    diretor: string;

    @Column({type: "varchar", length: 4, nullable: false})
    ano: number;

    constructor(titulo: string, descricao: string, diretor: string, ano: number)  {
        this.titulo = titulo;
        this.descricao = descricao;
        this.diretor = diretor;
        this.ano = ano;
    }

    
}