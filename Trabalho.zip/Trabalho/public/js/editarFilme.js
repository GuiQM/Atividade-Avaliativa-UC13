document.addEventListener('DOMContentLoaded', () => {
    const btnBuscar = document.getElementById('btnBuscar');
    const btnEnviar = document.getElementById('btnEnviar');


    btnBuscar.addEventListener('click', async () => {
        const id = document.getElementById('inpID').value.trim();
        if (!id) {
            alert("Digite um ID!");
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/filmes/${id}`);
            if (response.ok) {
                const filme = await response.json();
                document.getElementById('inpTit').value = filme.titulo;
                document.getElementById('inpDesc').value = filme.descricao;
                document.getElementById('inpDir').value = filme.diretor;
                document.getElementById('inpAno').value = filme.ano;
            } else {
                const data = await response.json();
                alert(data.message || "Filme não encontrado.");
            }
        } catch (error) {
            alert("Erro ao buscar filme: " + error.message);
        }
    });


    btnEnviar.addEventListener('click', async (e) => {
        e.preventDefault();

        const id = document.getElementById('inpID').value.trim();
        const titulo = document.getElementById('inpTit').value.trim();
        const descricao = document.getElementById('inpDesc').value.trim();
        const diretor = document.getElementById('inpDir').value.trim();
        const ano = document.getElementById('inpAno').value.trim();

        if (!id || !titulo || !descricao || !diretor || !ano) {
            alert("Preencha todos os campos!");
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/filmes/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ titulo, descricao, diretor, ano })
            });

            if (response.ok) {
                alert("Filme editado com sucesso!");
                window.location.href = "./paginaInicial.html";
            } else {
                const data = await response.json();
                alert(data.message || "Erro ao editar filme");
            }
        } catch (error) {
            alert("Erro na requisição: " + error.message);
        }
    });
});
