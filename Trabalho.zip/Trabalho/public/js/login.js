document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('btnConfirmar');

    btn.addEventListener('click', async (e) => {
        e.preventDefault();

        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();

        if (email === "" || password === "") {
            alert("INSIRA UM EMAIL E UMA SENHA!");
            return;
        }

        try {
            const response = await fetch('http://localhost:3000/api/users', {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password })
            });

            if (response.ok) {
                alert("Login realizado com sucesso!");
                window.location.href = "./pages/paginaInicial.html";
            } else {
                const data = await response.json();
                alert(data.message || "Erro ao efetuar login");
            }
        } catch (error) {
            alert("Erro na requisição: " + error.message);
        }
    });
});
