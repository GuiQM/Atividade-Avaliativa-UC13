document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('btnEnviar');

    btn.addEventListener('click', async (e) => {
        e.preventDefault();

        const titulo = document.getElementById('inpTit').value.trim();
        const descricao = document.getElementById('inpDesc').value.trim();
        const diretor = document.getElementById('inpDir').value.trim();
        const ano = document.getElementById('inpAno').value.trim();
               
        if (titulo === "" || descricao === "" || diretor === "" || ano === "") {
            alert("Preencha todos os campos!");
            return;
        }

        try {
            const response = await fetch('http://localhost:3000/api/filmes', {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ titulo, descricao, diretor, ano })
            });

            if (response.ok) {
                alert("Filme adicionado com sucesso!!");
                window.location.href = "./paginaInicial.html";
            } else {
                const data = await response.json();
                alert(data.message || "Erro ao adicionar filme");
            }
        } catch (error) {
            alert("Erro na requisição: " + error.message);
        }
    });
});