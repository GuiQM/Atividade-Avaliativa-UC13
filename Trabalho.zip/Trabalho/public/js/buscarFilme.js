document.addEventListener('DOMContentLoaded', () =>{
    const btnBuscar = document.getElementById('btnBuscar');

    btnBuscar.addEventListener('click', async () => {
        const id = document.getElementById('inpID').value.trim();
        if (!id) {
            alert("Digite um ID!");
            return;
        }

        try {
            const response = await fetch(`http://localhost:3000/api/filmes/${id}`);
            if (response.ok) {
                const filme = await response.json();
                document.getElementById('inpTit').value = filme.titulo;
                document.getElementById('inpDesc').value = filme.descricao;
                document.getElementById('inpDir').value = filme.diretor;
                document.getElementById('inpAno').value = filme.ano;
            } else {
                const data = await response.json();
                alert(data.message || "Filme não encontrado.");
            }
        } catch (error) {
            alert("Erro na requisição: " + error.message);
        }
    });
});