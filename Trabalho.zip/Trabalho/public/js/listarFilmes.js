document.addEventListener('DOMContentLoaded', () => {

  document.getElementById('carregarFilmes');

  carregarFilmes.addEventListener(async (e) => {
    e.preventDefault();
    const response = await fetch('http://localhost:3000/api/filmes/getAll');
    const filmes = await response.json();

    const textarea = document.getElementById('filmesListados');
    textarea.value = '';

    filmes.forEach(filme => {
      const informacoes = `ID: ${filme.id} | Título: ${filme.titulo} | Descrição: ${filme.descricao} | Diretor:: ${filme.diretor} | Ano: ${filme.ano}\n`;
      textarea.value += informacoes;
    });
  }
  )
});